
        <meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
        <meta content="IE=9" http-equiv="x-ua-compatible">
        <meta content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width, height=device-height" name="viewport">
        <meta property="og:image" content="" />
        <link rel="icon" href="#" type="image/x-icon" />
        
    <title><?php echo $array_template_pc['title'];?></title>
    <meta name="description" contnewv1.gifent="Play Game, Up load Apps Game Free, Free download apps mobile"/>        
    <meta name="keywords" content="mini game, web game, appstore mobile"/>            
    <meta property="og:title" content="Appstore iOS - Android | FREE Download Game"/>
    <meta property="og:description" content="Appstore iOS - Android | FREE Download Game"/>
    <meta property="og:image" content="#" />
    <link rel="canonical" href="#"/>
<?php echo $array_template_pc['embed_code'];?>





    <link rel="next" href="#" />
        

    <meta name="distribution" content="Global" />
    <meta name="revisit" content="1 days" />
    <meta name="geo.placename" content="US" />
    <meta name="geo.region" content="US" />
    <meta name="dc.creator" content="AppStore" />
    <meta name="generator" content="#" />
        <link type="text/css" rel="stylesheet" href="<?php echo $path;?>/library/v4/font/Roboto/roboto_font-1.02.css">
        <link type="text/css" rel="stylesheet" href="<?php echo $path;?>/library/v4/css/zmlayout-1.21.css">
        <link type="text/css" rel="stylesheet" href="<?php echo $path;?>/library/v4/css/zmcommon-1.18.css">
        <link type="text/css" rel="stylesheet" href="<?php echo $path;?>/library/v4/css/screen-1.72.css">
        <link type="text/css" rel="stylesheet" href="<?php echo $path;?>/library/v4/css/zmheader-1.34.css">
        <link type="text/css" rel="stylesheet" href="<?php echo $path;?>/library/v4/css/feed-1.23.css">
        <link type="text/css" rel="stylesheet" href="<?php echo $path;?>/library/v4/css/status-1.13.css">
       
        <link type="text/css" rel="stylesheet" href="<?php echo $path;?>/library/v4/css/zmchat-1.17.css"/>
        
        <link type="text/css" rel="stylesheet" href="<?php echo $path;?>/library/v4/appstore/css/appstoreicns-1.38.css"/>
        <link type="text/css" rel="stylesheet" href="<?php echo $path;?>/library/v4/appstore/css/zingappstore-1.41.css"/>
        <link type="text/css" rel="stylesheet" href="<?php echo $path;?>/library/v4/appstore/css/responsive-1.09.css">

<link type="text/css" rel="stylesheet" href="<?php echo $path;?>/library/v4/css/login.css">

            
        
        <script type="text/javascript" src="<?php echo $path;?>/file/zmjs/zmCore-1.65.min.js" ></script>    
        <script type="text/javascript" src="<?php echo $path;?>/file/zmjs/zm.ui-3.29.min.js"></script>
        <script type="text/javascript" src="<?php echo $path;?>/file/v4/js/common-1.89.min.js"></script>
        <script type="text/javascript" src="<?php echo $path;?>/file/zmjs/zm.autocomplete-2.02.min.js"></script>
        <script type="text/javascript" src="<?php echo $path;?>/file/v4/appstore/js/appstore.widget-1.01.min.js"></script>
        <script type="text/javascript" src="<?php echo $path;?>/file/v4/appstore/js/appstore-1.09.min.js"></script>
        <script type="text/javascript" src="<?php echo $path;?>/file/v4/js/swfobject.js" charset="utf-8" defer="defer" async="async"></script>
	<style type="text/css" media="screen">#zmchat-wrapper {visibility:hidden}</style>