<div class="fl">
<p>Copyright &copy; CLM corp <br>
 
2015</p>
</div>
<div class="rightctn"></div>
<div class="clr"></div>