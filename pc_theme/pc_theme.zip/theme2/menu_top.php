<div class="zmh appstore">
               <div class="zm_innerwrapper notlogined" id ="zmheader">
			<div class="zmhcont">
			<h1 class="zm_logo">
				<a href='#' title="Back To Home Page"></a>
			</h1>
        
        
        <!-- Buttons -->
        <div class="header_buttons">  
         
         
        </div>
        <!-- begin: partner sites -->
        <ul class="zm_partner">
            <li><a href="<?php echo $domainsite;?>/managerOffer/register.php" target="" title="App Store"><span>Register</span></a></li> 
            <li><a href="<?php echo $domainsite;?>/managerOffer/login.php" target="" title="App Store"><span>Login</span></a></li> 
            
           
        </ul>
        <!-- end: partner sites -->
        <div class="clr"></div>
        
        <!-- end: Notification -->
        <div class="clr"></div>
    </div>
</div>


            </div>            
            <div class="zas">
                <div id="zaswrapper" class="zaswrapper">
                  <div class="zas_inner"> <a class="applogo" href="./index.php"><img style="width:140px" src="<?php echo $array_template_pc['logo'];?>" alt=""></a>
                    <ul class="topnav">
                      <li>
                        <div class="showgame">
                            <a target="" class="titlenav" href="<?php echo $domainsite;?>/index.php?os=android">Android App</a>
                        </div>
                      </li>
                      
                      <li>
                        <div class="showgame">
                            <a target="" class="titlenav" href="<?php echo $domainsite;?>/index.php?os=ios">iOS App</a>
                        </div>
                      </li>
  
					<li>
                        <div class="showgame">
                            <a target="" class="titlenav" href="<?php echo $domainsite;?>/index.php?os=winphone">Windows Phone</a>
                        </div>
                      </li>
					  <li>
                        <div class="showgame">
                            <a target="" class="titlenav" href="<?php echo $domainsite;?>/index.php?os=pc">Computer</a>
                        </div>
                      </li>
					  
                    </ul>
                    </div>
                </div>
              </div>