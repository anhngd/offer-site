<div class="banner"> 
    <?php include("banner.php");?>
</div>
 <script type="text/javascript" src="<?php echo $path;?>/file/v4/appstore/js/slidebanner-1.01.min.js"></script>
<div id="zme-root"></div>
<div id="fb-root"></div>
<div class="zapp_hotline">
</div>
<div class="game_content">
<?php include("game_content.php");?>
</div>