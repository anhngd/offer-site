<ul class="footernav">
	<li><a href="#">Home</a></li>
	<li><a href="#">FAQs</a></li>
	<li><a href="#">Contact</a></li>
</ul>
<div class="footer-content">
   <p> Copyright © 2015</p>
</div>